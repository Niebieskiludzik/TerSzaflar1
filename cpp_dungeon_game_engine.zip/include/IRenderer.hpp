#pragma once
#include <string>
#include <vector>

struct Light {
    float x, y;
    float radius;
    float r, g, b; // Kolor światła [0..1]
    float intensity;
};

struct RenderEntity {
    float x, y;
    float angle;
    int type; // 0: Gracz, 1: Goblin, 2: Szkielet, 3: Boss Minotaur, 4: Pocisk, 5: Skrzynia
    int hp;
    int maxHp;
    bool isHit;
};

class IRenderer {
public:
    virtual ~IRenderer() = default;

    // Inicjalizacja i zamykanie kontekstu graficznego
    virtual void init(int screenWidth, int screenHeight, const std::string& title) = 0;
    virtual void shutdown() = 0;
    virtual bool shouldClose() = 0;

    // Pętla renderowania klatki
    virtual void beginFrame() = 0;
    virtual void endFrame() = 0;

    // Rysowanie mapy i pola widzenia (Field of View)
    virtual void drawMap(
        const std::vector<std::vector<int>>& map,
        const std::vector<std::vector<bool>>& fov,
        int mapWidth,
        int mapHeight,
        float playerX,
        float playerY
    ) = 0;

    // Rysowanie bytów (gracz, wrogowie, pociski, skrzynie)
    virtual void drawEntities(
        const std::vector<RenderEntity>& entities,
        float playerX,
        float playerY
    ) = 0;

    // Rysowanie dynamicznego oświetlenia (Shadery / Światła punktowe)
    virtual void drawLighting(const std::vector<Light>& lights, float playerX, float playerY) = 0;

    // Rysowanie interfejsu (HUD: zdrowie, punkty, broń)
    virtual void drawHUD(int hp, int maxHp, int score, int level, const std::string& weapon) = 0;
};
