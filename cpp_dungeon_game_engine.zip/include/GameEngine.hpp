#pragma once
#include <memory>
#include <vector>
#include "IRenderer.hpp"
#include "DungeonMap.hpp"
#include "EntityManager.hpp"

enum class GameState {
    PLAYING,
    PAUSED,
    VICTORY,
    GAME_OVER
};

class GameEngine {
public:
    explicit GameEngine(std::unique_ptr<IRenderer> renderer);
    ~GameEngine() = default;

    void init();
    void processInput();
    void update(float dt);
    void render();

    bool isRunning() const { return m_running; }
    void restartLevel(bool nextLevel);

private:
    void computeFOV();
    void checkCollisions(float dt);

    std::unique_ptr<IRenderer> m_renderer;
    DungeonMap m_map;
    EntityManager m_entities;
    GameState m_state = GameState::PLAYING;

    std::vector<std::vector<bool>> m_visibleTiles;
    std::vector<std::vector<bool>> m_exploredTiles;
    std::vector<Light> m_lights;

    int m_level = 1;
    bool m_running = true;
};
