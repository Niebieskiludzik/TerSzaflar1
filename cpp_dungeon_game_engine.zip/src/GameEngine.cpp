#include "GameEngine.hpp"
#include <cmath>
#include <algorithm>

GameEngine::GameEngine(std::unique_ptr<IRenderer> renderer)
    : m_renderer(std::move(renderer)), m_map(24, 24) {}

void GameEngine::init() {
    m_map.generate();
    m_entities.spawnPlayer(m_map.getStartX(), m_map.getStartY());
    m_entities.spawnEnemies(m_map);

    m_visibleTiles.assign(m_map.getHeight(), std::vector<bool>(m_map.getWidth(), false));
    m_exploredTiles.assign(m_map.getHeight(), std::vector<bool>(m_map.getWidth(), false));

    computeFOV();
}

void GameEngine::processInput() {
    if (m_renderer->shouldClose()) {
        m_running = false;
        return;
    }
    // Wejście klawiatury jest odpytywane w m_renderer->pollInput()
}

void GameEngine::update(float dt) {
    if (m_state != GameState::PLAYING) return;

    // 1. Aktualizacja gracza i pocisków
    m_entities.update(dt, m_map);

    // 2. Aktualizacja świateł (pochodnie na ścianach)
    m_lights.clear();
    const auto& player = m_entities.getPlayer();
    m_lights.push_back({ player.x, player.y, 4.5f, 1.0f, 0.8f, 0.4f, 1.0f });

    for (const auto& torch : m_map.getTorches()) {
        m_lights.push_back({ torch.x, torch.y, 3.8f, 1.0f, 0.6f, 0.2f, 0.9f });
    }

    // 3. Obliczenie promieni FOV
    computeFOV();

    // 4. Warunek zwycięstwa / przegranej
    if (m_entities.getPlayer().hp <= 0) {
        m_state = GameState::GAME_OVER;
    }
    if (m_map.isExit(player.x, player.y)) {
        m_state = GameState::VICTORY;
    }
}

void GameEngine::render() {
    m_renderer->beginFrame();

    const auto& player = m_entities.getPlayer();

    // Krok 1: Rysowanie kafelków mapy
    m_renderer->drawMap(
        m_map.getGrid(),
        m_visibleTiles,
        m_map.getWidth(),
        m_map.getHeight(),
        player.x,
        player.y
    );

    // Krok 2: Rysowanie dynamicznego oświetlenia
    m_renderer->drawLighting(m_lights, player.x, player.y);

    // Krok 3: Rysowanie postaci, potworów i pocisków
    m_renderer->drawEntities(m_entities.getRenderData(), player.x, player.y);

    // Krok 4: Rysowanie interfejsu gracza
    m_renderer->drawHUD(player.hp, player.maxHp, player.score, m_level, player.weaponName);

    m_renderer->endFrame();
}

void GameEngine::computeFOV() {
    // Algorytm rzucania promieni widzenia (Raycasting FOV)
    for (auto& row : m_visibleTiles) {
        std::fill(row.begin(), row.end(), false);
    }

    const auto& player = m_entities.getPlayer();
    const int numRays = 180;
    const float maxDist = 8.0f;

    for (int i = 0; i < numRays; ++i) {
        float angle = (float)i * (2.0f * 3.14159f / (float)numRays);
        float cosA = std::cos(angle);
        float sinA = std::sin(angle);

        float dist = 0.0f;
        while (dist < maxDist) {
            dist += 0.2f;
            float rx = player.x + cosA * dist;
            float ry = player.y + sinA * dist;
            int tx = (int)rx;
            int ty = (int)ry;

            if (tx >= 0 && tx < m_map.getWidth() && ty >= 0 && ty < m_map.getHeight()) {
                m_visibleTiles[ty][tx] = true;
                m_exploredTiles[ty][tx] = true;
                if (m_map.isSolid(tx, ty)) break; // Ściana blokuje promień
            } else {
                break;
            }
        }
    }
}
