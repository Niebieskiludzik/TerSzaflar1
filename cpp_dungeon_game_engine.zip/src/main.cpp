#include <iostream>
#include <memory>
#include <chrono>
#include "GameEngine.hpp"
#include "IRenderer.hpp"
#include "ConsoleRenderer.hpp"

#ifdef ENABLE_RAYLIB
#include "RaylibRenderer.hpp"
#endif

int main() {
    std::cout << "===========================================\n";
    std::cout << "   C++ DUNGEON ENGINE & GAME ARCHITECTURE  \n";
    std::cout << "===========================================\n";

    // 1. Wybór architektury renderowania (Wzorzec Strategy / Odwrócenie Zależności)
    // Dzięki interfejsowi IRenderer możesz w 1 linii podmienić grafikę z ASCII na Raylib lub OpenGL!
    std::unique_ptr<IRenderer> renderer;

#ifdef ENABLE_RAYLIB
    renderer = std::make_unique<RaylibRenderer>();
#else
    renderer = std::make_unique<ConsoleRenderer>();
#endif

    // 2. Inicjalizacja okna / konsoli
    renderer->init(960, 600, "C++ Dungeon Engine");

    // 3. Utworzenie instancji silnika gry
    GameEngine engine(std::move(renderer));
    engine.init();

    // 4. Stała pętla gry (Game Loop z Delta Time)
    auto previousTime = std::chrono::high_resolution_clock::now();

    while (engine.isRunning()) {
        auto currentTime = std::chrono::high_resolution_clock::now();
        float dt = std::chrono::duration<float, std::chrono::seconds::period>(
            currentTime - previousTime
        ).count();
        previousTime = currentTime;

        // Ogranicznik skrajnych spadków klatek
        if (dt > 0.1f) dt = 0.1f;

        // Krok A: Obsługa wejścia użytkownika (klawiatura / mysz)
        engine.processInput();

        // Krok B: Aktualizacja logiki świata (fizyka, SI wrogów, kolizje)
        engine.update(dt);

        // Krok C: Renderowanie aktualnej klatki przez podpięty renderer
        engine.render();
    }

    std::cout << "Silnik zakonczyl dzialanie pomyslnie.\n";
    return 0;
}
