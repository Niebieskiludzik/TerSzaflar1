#include "ConsoleRenderer.hpp"
#include <iostream>
#include <cmath>

void ConsoleRenderer::init(int, int, const std::string&) {
    std::cout << "\033[2J\033[H"; // Wyczysc konsole ANSI
    std::cout << "Konsola ASCII zainicjalizowana.\n";
}

void ConsoleRenderer::shutdown() {}

bool ConsoleRenderer::shouldClose() {
    return false;
}

void ConsoleRenderer::beginFrame() {
    // Ustaw kursor konsoli na poczatek (0,0) bez migotania
    std::cout << "\033[H";
}

void ConsoleRenderer::endFrame() {
    std::cout.flush();
}

void ConsoleRenderer::drawMap(
    const std::vector<std::vector<int>>& map,
    const std::vector<std::vector<bool>>& fov,
    int mapWidth,
    int mapHeight,
    float playerX,
    float playerY
) {
    const int viewW = 40;
    const int viewH = 20;

    int startX = (int)playerX - viewW / 2;
    int startY = (int)playerY - viewH / 2;

    for (int y = 0; y < viewH; ++y) {
        for (int x = 0; x < viewW; ++x) {
            int mx = startX + x;
            int my = startY + y;

            if (mx == (int)playerX && my == (int)playerY) {
                std::cout << "\033[1;36m@\033[0m"; // Gracz
                continue;
            }

            if (mx < 0 || mx >= mapWidth || my < 0 || my >= mapHeight) {
                std::cout << ' ';
                continue;
            }

            if (!fov[my][mx]) {
                std::cout << ' '; // Mgla wojny
                continue;
            }

            if (map[my][mx] == 1) {
                std::cout << "\033[1;37m#\033[0m"; // Sciana
            } else if (map[my][mx] == 3) {
                std::cout << "\033[1;35mO\033[0m"; // Wyjscie
            } else {
                std::cout << "\033[0;30m.\033[0m"; // Podloga
            }
        }
        std::cout << '\n';
    }
}

void ConsoleRenderer::drawEntities(const std::vector<RenderEntity>&, float, float) {}
void ConsoleRenderer::drawLighting(const std::vector<Light>&, float, float) {}

void ConsoleRenderer::drawHUD(int hp, int maxHp, int score, int level, const std::string& weapon) {
    std::cout << "HP: " << hp << "/" << maxHp 
              << " | WYNIK: " << score 
              << " | POZIOM: " << level 
              << " | BRON: " << weapon << "\n";
}
