/**
 * OpenGL 3.3+ Core Profile Renderer
 * Pokazuje jak w zaawansowany sposob renderowac gre za pomoca buforow VBO, VAO i shaderow GLSL.
 */
#include "IRenderer.hpp"
#include <string>

// Kod shadera wierzcholkowego GLSL (Vertex Shader)
const char* vertexShaderSource = R"(
#version 330 core
layout (location = 0) in vec3 aPos;
layout (location = 1) in vec2 aTexCoord;
layout (location = 2) in vec3 aNormal;

out vec2 TexCoord;
out vec3 FragPos;
out vec3 Normal;

uniform mat4 model;
uniform mat4 view;
uniform mat4 projection;

void main() {
    FragPos = vec3(model * vec4(aPos, 1.0));
    Normal = mat3(transpose(inverse(model))) * aNormal;
    TexCoord = aTexCoord;
    gl_Position = projection * view * vec4(FragPos, 1.0);
}
)";

// Kod shadera fragmentow GLSL (Fragment Shader z modelem Phong i swiatlem punktowym)
const char* fragmentShaderSource = R"(
#version 330 core
out vec4 FragColor;

in vec2 TexCoord;
in vec3 FragPos;
in vec3 Normal;

uniform sampler2D texture_diffuse;
uniform vec3 lightPos;
uniform vec3 lightColor;
uniform vec3 viewPos;

void main() {
    // 1. Swiatlo otoczenia (Ambient)
    float ambientStrength = 0.15;
    vec3 ambient = ambientStrength * lightColor;

    // 2. Swiatlo rozproszone (Diffuse)
    vec3 norm = normalize(Normal);
    vec3 lightDir = normalize(lightPos - FragPos);
    float diff = max(dot(norm, lightDir), 0.0);
    vec3 diffuse = diff * lightColor;

    // 3. Zanikanie swiatla z odlegloscia (Attenuation)
    float distance = length(lightPos - FragPos);
    float attenuation = 1.0 / (1.0 + 0.09 * distance + 0.032 * (distance * distance));

    vec4 texColor = texture(texture_diffuse, TexCoord);
    vec3 result = (ambient + diffuse * attenuation) * texColor.rgb;
    FragColor = vec4(result, texColor.a);
}
)";
