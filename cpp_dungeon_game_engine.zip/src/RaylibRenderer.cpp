#ifdef ENABLE_RAYLIB
#include "RaylibRenderer.hpp"
#include <raylib.h>
#include <cmath>

// Definicja kamery 3D śledzącej gracza pod kątem 60 stopni (Pitch 60°, Yaw 45°)
static Camera3D s_camera3D = {
    .position = { 0.0f, 14.0f, 10.0f },
    .target = { 0.0f, 0.0f, 0.0f },
    .up = { 0.0f, 1.0f, 0.0f },
    .fovy = 45.0f,
    .projection = CAMERA_PERSPECTIVE
};

void RaylibRenderer::init(int screenWidth, int screenHeight, const std::string& title) {
    InitWindow(screenWidth, screenHeight, title.c_str());
    SetTargetFPS(60);
}

void RaylibRenderer::shutdown() {
    CloseWindow();
}

bool RaylibRenderer::shouldClose() {
    return WindowShouldClose();
}

void RaylibRenderer::beginFrame() {
    BeginDrawing();
    ClearBackground(GetColor(0x090d16ff));
}

void RaylibRenderer::endFrame() {
    EndDrawing();
}

void RaylibRenderer::drawMap(
    const std::vector<std::vector<int>>& map,
    const std::vector<std::vector<bool>>& fov,
    int mapWidth,
    int mapHeight,
    float playerX,
    float playerY
) {
    // =========================================================================
    // KAMERA 3D ŚLEDZĄCA GRACZA POD KĄTEM 60 STOPNI (Pitch 60°, Yaw 45°)
    // Kamera płynnie przemieszcza się razem z graczem pod wybranym kątem!
    // =========================================================================
    const float pitchRad = 60.0f * (3.14159265f / 180.0f); // Kąt nachylenia 60°
    const float yawRad   = 45.0f * (3.14159265f / 180.0f); // Kąt obrotu 45°
    const float distance = 15.0f; // Dystans kamery

    // Cel kamery: pozycja gracza na podłodze
    s_camera3D.target = (Vector3){ playerX, 0.5f, playerY };

    // Kamera podąża za graczem, zachowując stały kąt nachylenia 60 stopni:
    float horizDist = distance * cosf(pitchRad);
    float heightDist = distance * sinf(pitchRad);

    s_camera3D.position = (Vector3){
        playerX + horizDist * sinf(yawRad),
        heightDist,
        playerY + horizDist * cosf(yawRad)
    };

    BeginMode3D(s_camera3D);

    // 1. Rysowanie podłogi 3D
    DrawPlane((Vector3){ 12.0f, 0.0f, 12.0f }, (Vector2){ (float)mapWidth, (float)mapHeight }, GetColor(0x0f172aff));
    DrawGrid(mapWidth, 1.0f);

    // 2. Rysowanie trójwymiarowych ścian (prostopadłościany 3D)
    for (int y = 0; y < mapHeight; ++y) {
        for (int x = 0; x < mapWidth; ++x) {
            if (map[y][x] == 1) {
                bool isVisible = fov[y][x];
                Color wallColor = isVisible ? GetColor(0x475569ff) : GetColor(0x1e293bff);

                // Sześcian ściany o wysokości 1.2 jednostki w 3D:
                Vector3 pos = { (float)x + 0.5f, 0.6f, (float)y + 0.5f };
                Vector3 size = { 1.0f, 1.2f, 1.0f };
                DrawCube(pos, size.x, size.y, size.z, wallColor);
                DrawCubeWires(pos, size.x, size.y, size.z, GetColor(0x334155ff));
            } else if (map[y][x] == 3) {
                // Portal wyjściowy w 3D
                DrawCylinder((Vector3){ (float)x + 0.5f, 0.05f, (float)y + 0.5f }, 0.45f, 0.45f, 0.1f, 16, SKYBLUE);
            }
        }
    }

    EndMode3D();
}

void RaylibRenderer::drawEntities(
    const std::vector<RenderEntity>& entities,
    float playerX,
    float playerY
) {
    BeginMode3D(s_camera3D);

    for (const auto& e : entities) {
        Vector3 pos = { e.x, 0.5f, e.y };

        if (e.type == 0) {
            // Gracz w 3D (Cylinder bohatera z niebieską zbroją)
            DrawCylinder((Vector3){ e.x, 0.0f, e.y }, 0.35f, 0.35f, 0.9f, 16, SKYBLUE);
            DrawSphere((Vector3){ e.x, 1.0f, e.y }, 0.25f, BLUE);
            // Wskaźnik kierunku na ziemi:
            DrawLine3D(
                (Vector3){ e.x, 0.1f, e.y },
                (Vector3){ e.x + cosf(e.angle) * 0.7f, 0.1f, e.y + sinf(e.angle) * 0.7f },
                YELLOW
            );
        } else if (e.type == 1) {
            // Goblin w 3D (zielony)
            DrawCylinder((Vector3){ e.x, 0.0f, e.y }, 0.3f, 0.3f, 0.7f, 12, GREEN);
        } else if (e.type == 2) {
            // Szkielet w 3D (jasnoszary)
            DrawCylinder((Vector3){ e.x, 0.0f, e.y }, 0.3f, 0.3f, 0.8f, 12, LIGHTGRAY);
        } else if (e.type == 3) {
            // Boss Minotaur w 3D (czerwony olbrzym)
            DrawCylinder((Vector3){ e.x, 0.0f, e.y }, 0.55f, 0.55f, 1.3f, 16, MAROON);
        } else if (e.type == 4) {
            // Kula ognia w 3D lecąca na wysokości z = 0.5:
            DrawSphere(pos, 0.2f, ORANGE);
        }
    }

    EndMode3D();
}

void RaylibRenderer::drawLighting(const std::vector<Light>& lights, float playerX, float playerY) {}

void RaylibRenderer::drawHUD(int hp, int maxHp, int score, int level, const std::string& weapon) {
    DrawText("KAMERA 3D: ŚLEDZI GRACZA POD KĄTEM 60° (PITCH 60°, YAW 45°)", 20, 20, 18, YELLOW);
    DrawText(TextFormat("HP: %d/%d | WYNIK: %d | POZIOM: %d", hp, maxHp, score, level), 20, 45, 16, WHITE);
    DrawText(TextFormat("BRON: %s [SPACJA/KLIK - ATAK]", weapon.c_str()), 20, 68, 14, GREEN);
}
#endif
